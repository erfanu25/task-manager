package com.hmtmcse.tm.controllers.api

import com.hmtmcse.gs.GsRestProcessor
import com.hmtmcse.tm.AuthenticationDefinitionService
import com.hmtmcse.tm.TodoDefinitionService

class ApiTodoV1Controller extends GsRestProcessor {

    TodoDefinitionService todoDefinitionService

    def postQuickCreate() {
        return create(todoDefinitionService.create())
    }

    def postUpdate() {
        return update(todoDefinitionService.update())
    }

    def getList() {
        return list(todoDefinitionService.list())
    }

    def getDetails() {
        return details(todoDefinitionService.details())
    }

    def deleteDelete() {
        return delete(todoDefinitionService.delete())
    }


}
