package com.hmtmcse.tm.controllers.api

import com.hmtmcse.gs.GsRestProcessor
import com.hmtmcse.tm.ComplexityDefinitionService
import com.hmtmcse.tm.TodoDefinitionService

class ApiComplexityV1Controller extends GsRestProcessor {

    ComplexityDefinitionService complexityDefinitionService

    def postQuickCreate() {
        return create(complexityDefinitionService.create())
    }

    def postUpdate() {
        return update(complexityDefinitionService.update())
    }

    def getList() {
        return list(complexityDefinitionService.list())
    }

    def getDetails() {
        return details(complexityDefinitionService.details())
    }

    def deleteDelete() {
        return delete(complexityDefinitionService.delete())
    }

}
